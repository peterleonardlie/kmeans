# K-means
#
# kmeans(data, k, gnuplot)
#   Centroids = Randomly select k points 
#   Do:
#    Assign points to nearest Centroids
#    For each cluster
#    Calculate centroid
#    Assign points to nearest Centroids
#    Until no new assignments
#

import math
import random
import time
import isclust
import msvcrt   # Need this if you want to control using keybaord, only for Windows

# Cluster data into k clusters
# data: a list of objects. Each object is a list. The first attribute is the cluster label
# k: int, the number of clusters
def kmeans(data, k, gnuplot):
  centroids = selectRandom(k, len(data[0])-1, 0, 10)  # each medoid is an object

  while( 1 ):
    # assign objects to nearest centroids (expectation step)
    changed = assignToCluster(data, centroids)

    # calculate new centroid (maximisation step)
    centroids = calcCentroids(data,k)
    print "Centroids", centroids

    # TODO:
    # calculate SSE. calcSSE is not implemented
    sse = calcSSE(data, centroids)

    # Uncommet this to draw data, centroids, and assignments
    isclust.redraw(gnuplot, data, centroids, "X", "Y", 0, 10, 0, 10, "Kmeans")

    # Uncomment this to control steps using keyboard
    # Only works for Windows
    ch = msvcrt.getch()
    if( ch == 'q' or ch == 'Q'):
      return [sse, centroids, data]

    if not changed:
      return [sse, centroids, data]

def calcSSE(data, centroids):
  # TODO
  # implement SSE calculation
  # distance to the nearest cluster
  # square errors and sum them
  total = 0
  for i in data:
    centroidsNum = findClosest(i, centroids)
    closeCen = centroids[centroidsNum]
    data = disimilarity(i,closeCen)
    dataSquare = data * data
    total += dataSquare

  return total

      
def zeros(k):
  d = []
  for i in range(k):
    d.append(0)
  return d

def calcCentroids(data, k):
  d = len(data[0])
  centroids = []
  for i in range(k):
    c = zeros(d)
    n = 0
    for p in data:
      if( p[0] == i ):
        addVectors(c, p)
        n += 1
    if( n > 0 ):
      divVector(c,n)
    else:
      c = selectRandom(1, d-1, 0, 10)[0]
    centroids.append(c)
  return centroids

def addVectors(c,p):
  for i in range(len(c)):
    c[i] += p[i]

def divVector(c,n):
  for i in range(len(c)):
    c[i] = c[i]/n

def assignToCluster(data, centroids):
  changed = False
  for p in data:
    i = findClosest(p, centroids)
    if( p[0] != i):
      p[0] = i
      changed = 1
  return changed

def findClosest(p, centroids):
  minD = -1
  cidx = -1
  for i in range(len(centroids)):
    d = disimilarity(centroids[i], p)
    if( minD < 0 or d < minD):
      minD = d
      cidx = i
  print cidx
  return cidx

# Measure dissimilarity between x1 and x2
def disimilarity(x1,x2):
  # euclidean distance
  d = 0
  for i in range(len(x1)-1):
    print x1
    d += math.pow(x1[i+1] - x2[i+1],2)
  return math.sqrt(d)

# Randomly select k number of centroids
def selectRandom(k, dimension, vmin, vmax):
  centroids = []
  for i in range(k):
    p = [0]
    for j in range(dimension):
      p.append( random.random() * (vmax - vmin) + vmin )
    centroids.append(p)
  return centroids

# Generate test data: 2D data points centred around cx and cy within the diameter
def genDataXY(NumPoints, sigma, cx, cy, uniform=False):
  db = []
  for i in range(NumPoints):
    if( uniform ):
      x = (random.random() - 0.5) * sigma + cx
      y = (random.random() - 0.5) * sigma + cy
    else:
      x = random.gauss(cx, sigma)
      y = random.gauss(cy, sigma)
    db.append([0,x,y])
  return db

# Read svm sparse format from file 'fname' (with labels only)
# output: [dimension, data[[clusterAssigned, attribte1,...], labels[]]
def readSVMLight(fname):
  dimension = 0
  data = []
  labels = []
  for line in open(fname).readlines():
    label, lineattr = line.split(' ', 1)
    attr = {0:0}
    for e in lineattr.split():
      index,value= e.split(":")
      d = int(index)
      attr[d] = float(value)
      if d > dimension:
        dimension = d
    data.append(attr)
    labels.append(float(label)) #float in case of regression
    
  data2 = []
  for i in range(len(data)):
    d = [0] * (dimension + 1)
    dic = data[i]
    for k in dic.keys():
      d[k] = dic[k]
    data2.append(d)

  return [dimension, data2, labels]

# build contingency table assuming cluster0 is clusterZeroLabel
def contingencyTable(centroids, data, lables, clusterLabels):
  TP = 0
  TN = 0
  FP = 0
  FN = 0
  for i in range(len(data)):
    d = data[i]
    clusterID = d[0]
    label = labels[i]
    if label > 0:  # positive
      if clusterLabels[clusterID] == label:
        TP = TP + 1
      else:
        FN = FN + 1
    else:  # negative
      if clusterLabels[clusterID] == label:
        TN = TN + 1
      else:
        FP = FP + 1
  N = TP + TN + FP + FN

  print "   +  -   classified"
  print " +", TP, FN
  print " -", FP, TN

  print "Error = ", (FN+FP)/N

#-----------------------------------------------------------
# Program starts from here
#-----------------------------------------------------------
if __name__ == '__main__':

  # Uncomment this if you want to initialize GNUPlot for visualizing clustering
  gnuplot = isclust.getGnuPlot()  
  time.sleep(1)

  print "Type q to quit"

  # Randomly generate test data. k=3, 3 clusters
  #sigma = 0.5
  #NumPoints = 20
  #db1 = genDataXY(NumPoints, sigma, 2, 2) # return a list of lists. Each list [clusterAssignment=0, x0, x1,....]
  #db2 = genDataXY(NumPoints, sigma, 6, 6)
  #db3 = genDataXY(NumPoints, sigma, 2, 6)
  #db = db1 + db2 + db3
  #k = 3

  # you can also define your own data. Each first element is cluster assigned. initially 0
  data = [[0,1,1], [0,1, 2], [0,1,1.5], [0, 5, 4], [0, 4.5, 4], [0, 4, 4.8]]

  # You can also read from file
  [dim, db, labels] = readSVMLight("C:\Users\Peter Alienware\Downloads\Python_kmeans_packv2\kmeans_pack/test.dat")
  k = 2
  print "Dimension of data: ", dim
  print "Data read: ", db
  print "Labels of data: ", labels

  [sse, centroids, data] = kmeans(db, k, gnuplot)
  print "---------------------------------------"
  print "Clustering now....."
  print "Clustering done"
  print "Centroids", centroids
  print db  # check assignments

  # TODO
  # Calculate contingency table. !! use smaller error rate
  print "---------------------------------------"
  print "Contingency table for [-1,1] cluster label"
  contingencyTable(centroids, data, labels, [-1,1])
  print "---------------------------------------"
  print "Contingency table for [1,-1] cluster label"
  contingencyTable(centroids, data, labels, [1,-1])



  
