# Author
#    Dr Insu Song.    insu.song@jcu.edu.au
#    License LGPL
#
import random
import os, sys
from threading import Thread
from subprocess import *
import math
import msvcrt

def checkKey():
  ch = msvcrt.getch()
  if( ch == 'q' or ch == 'Q' ):
    return 1
  else:
    return False

#--------------------------------------------------
# Generate data points
# Each point = [0, x_1,...,x_NumPoints]
def genData(dimension, NumPoints, vmin, vmax, uniform=False):
  db = []
  for i in range(NumPoints):
    d = [0]
    for j in range(dimension):
      if( uniform ):
        e = random.random()*(vmax - vmin) + vmin
      else:
        e = random.gauss((vmax - vmin)/2, vmax - vmin)
      d.append(e)
    db.append(d)
  return db

# generate 2D data points centered around cx and cy within the diameter
def genDataXY(NumPoints, sigma, cx, cy, uniform=False):
  db = []
  for i in range(NumPoints):
    if( uniform ):
      x = (random.random() - 0.5) * sigma + cx
      y = (random.random() - 0.5) * sigma + cy
    else:
      x = random.gauss(cx, sigma)
      y = random.gauss(cy, sigma)
    db.append([0,x,y])
  return db

def getGnuPlot():
  # svmtrain and gnuplot executable
  is_win32 = (sys.platform == 'win32')
  if not is_win32:
    gnuplot_exe = "/usr/bin/gnuplot"
  else:
    # example for windows
    gnuplot_exe = r"./gnuplot/pgnuplot.exe" # r"Y:\Progs\gnuplot\bin\pgnuplot.exe"

  assert os.path.exists(gnuplot_exe),"gnuplot executable not found"
  gnuplot = Popen(gnuplot_exe,stdin = PIPE).stdin
  return gnuplot

def openGnuPlotTerm(gnuplot, xlabel, ylabel, x_begin, x_end, y_begin, y_end, title, tofile=False):
  is_win32 = (sys.platform == 'win32')
  if tofile:
      gnuplot.write( "set term png transparent small\n".encode())
      gnuplot.write( ("set output \"%s\"\n" % png_filename.replace('\\','\\\\')).encode())
  elif is_win32:
      gnuplot.write("set term windows\n".encode())
  else:
      gnuplot.write( "set term x11\n".encode())

  gnuplot.write(("set xlabel \"%s\"\n" % xlabel).encode())
  gnuplot.write(("set ylabel \"%s\"\n" % ylabel).encode())
  gnuplot.write(("set xrange [%s:%s]\n" % (x_begin, x_end)).encode())
  gnuplot.write(("set yrange [%s:%s]\n" % (y_begin, y_end)).encode())

  gnuplot.write("set view 0,0\n".encode())
  gnuplot.write(("set title \"%s\"\n" % title).encode())
  gnuplot.write("unset label\n".encode())

  gnuplot.write(("set style line 1 lt 2 lw 2 pt 3 ps 0.5 linecolor rgb \"red\"\n").encode())
  gnuplot.write(("set style line 2 lt 2 lw 2 pt 3 ps 0.5 linecolor rgb \"green\"\n").encode())
  gnuplot.write(("set style line 3 lt 2 lw 2 pt 3 ps 0.5 linecolor rgb \"blue\"\n").encode())
  gnuplot.write(("set style line 4 lt 2 lw 2 pt 3 ps 0.5 linecolor rgb \"black\"\n").encode())
  gnuplot.write(("set style line 5 lt 2 lw 2 pt 3 ps 0.5 linecolor rgb \"magenta\"\n").encode())
  gnuplot.write(("set style line 6 lt 2 lw 2 pt 3 ps 0.5 linecolor rgb \"yellow\"\n").encode())
  gnuplot.write(("set style line 7 lt 2 lw 2 pt 3 ps 0.5 linecolor rgb \"cyan\"\n").encode())
  gnuplot.write(("set style line 8 lt 2 lw 2 pt 3 ps 0.5 linecolor rgb \"orange\"\n").encode())
  gnuplot.write(("set style line 9 lt 2 lw 2 pt 3 ps 0.5 linecolor rgb \"violet\"\n").encode())
    
#--------------------------------------------------
# Draw data points in dataPoints and center points in centerPoints
#
# Each data point: [center_index, x, y]
# Each center point: [0, x, y]
#
#--------------------------------------------------
def redraw(gnuplot, dataPoints, centerPoints, xlabel, ylabel, x_begin, x_end, y_begin, y_end, title, tofile=False):
  if len(dataPoints) == 0: return
  openGnuPlotTerm(gnuplot, xlabel, ylabel, x_begin, x_end, y_begin, y_end, title, tofile)

  i = 1
  for p in dataPoints:
    gnuplot.write(("set arrow %s from %s,%s to %s,%s nohead linetype %s\n" % (i, p[1], p[2], centerPoints[p[0]][1], centerPoints[p[0]][2], p[0])).encode())
    i += 1

  # plot dataPoints
  gnuplot.write("plot \"-\" title \"Data\" ls 1 with points, \"-\" title \"Medoids\" ls 3 with circles\n".encode())
  for p in dataPoints:
    c = ("%s %s\n" % (p[1],p[2])).encode()
    #print c
    gnuplot.write(c)
  gnuplot.write("e\n".encode())

  for p in centerPoints:
    c = ("%s %s 0.1\n" % (p[1],p[2])).encode()
    #print c
    gnuplot.write(c)
  gnuplot.write("e\n".encode())
  gnuplot.write("\n".encode()) # force gnuplot back to prompt when term set failure

  gnuplot.flush()

# Measure disimilarity between x1 and x2
def disimilarity(x1,x2):
  # eclidian distance
  d = 0
  for i in range(len(x1)-1):
    #print x1
    d += math.pow(x1[i+1] - x2[i+1],2)
  return math.sqrt(d)
