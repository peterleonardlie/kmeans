
import static java.lang.Double.MAX_VALUE;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Peter Leonard
 */
public class Running {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.print("Type the name of file what you want to load: ");
        String filename=input.next();
        ReadFile file = new ReadFile(filename);
        while(file.unloaded){
            System.out.print("Try again: ");
            filename=input.next();
            file=new ReadFile(filename);
        }
        Scanner input2=new Scanner(System.in);
        System.out.print("Type the number of test you want to run: ");
        
        int repeat = input2.nextInt();
        int size = 0,test = 1,Cnum = 0;
        int[] Size=new int[1000];
        double bestSSE = MAX_VALUE;
        int bestTest = 0;
        for(int i=1;i<=repeat;i++){
          //  System.out.println("This is "+i+" times to run:");
            KM_method KM = new KM_method(file);
            Cnum = KM.k;
            double sse = KM.SSE/(float)KM.rowsNum;
            System.out.println("\t Test "+test);
            System.out.println("Runnig: "+KM.times+" times for stable Centroid. ");
            System.out.println("SSE: "+sse+". ");
            if(sse<bestSSE)
            {
                bestTest = test;
                bestSSE=sse;
                for(int j=0;j<KM.k;j++)
                {
                    Size[j]=KM.protoClusters[j].Size;
                }
            }
            for(int j=0;j<KM.k;j++){
                size = KM.protoClusters[j].Size;
                float percent = (float)size/(float)KM.rowsNum*100;
                System.out.println("Cluster# "+j+"Number of Value: "+size +"("+percent+"%)");
            }
            test++;
            System.out.println("\n ==================================== \n");
        }
        
        System.out.println("The best Group has SSE "+bestSSE);
        System.out.println("This can be found in Test no. "+bestTest);
        int total = 0;
         for(int j=0;j<Cnum;j++)
        {
            total+=Size[j];
        }
        for(int j=0;j<Cnum;j++)
        {
            System.out.println("Cluster# "+j+"Number of Value: "+Size[j]+"("+((float)Size[j]/(float)total*100)+"%)");
        }
        
    }
        
}

