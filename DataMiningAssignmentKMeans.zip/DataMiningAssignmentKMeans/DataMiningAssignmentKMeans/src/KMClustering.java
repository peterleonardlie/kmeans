/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Peter Leonard
 */
public class KMClustering {
    int Size;
    double SSE;
    int[] CurGroup;
    double[] Centroid, Carrier, distances;
    double[][] Carry;
    KMClustering(double[][] coordinatesRows)
    {
        Centroid = new double[coordinatesRows[0].length];
    }
}
