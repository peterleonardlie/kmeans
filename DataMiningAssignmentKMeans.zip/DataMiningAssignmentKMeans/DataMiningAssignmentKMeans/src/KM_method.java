
import static java.lang.Double.MAX_VALUE;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Peter Leonard
 */
public class KM_method {
    public String[] Lines;
    public int[] ClusterAssign;
    public double[] max,min;
    public double[][] coordinates,mDistanceCache,newCentroids,maxmin;
    public KMClustering[] protoClusters;
    public double ranNum,SSE,sum;
    public int rowsNum,columnIndex,k,lines,ClusterLen,times;
    public boolean UNDONE;
    Scanner input=new Scanner(System.in);
    @SuppressWarnings("empty-statement")
            
    KM_method(ReadFile file)
    {
        k = 4;
        times = 1;
        UNDONE = true;
        rowsNum = file.size-1;
        columnIndex = file.attributeNum;
        ClusterAssign = new int[rowsNum];
        coordinates = new double[rowsNum][columnIndex];
        maxmin = new double[columnIndex][2];
        Random random = new Random();
        int rand;
        
        for(int i=1;i<file.size;i++)
        {
            lines++;
            Lines = file.datalist[i].split(";");
            for(int j=0;j<coordinates[i-1].length;j++)
            {
                coordinates[i-1][j] = Double.valueOf(Lines[j]);       
            }
        }
        
        //Create ‘k' KMClustering Objects for each point
        protoClusters = new KMClustering[k];
        
        //Assign the first 'k' point to be the center point of 'k' Clusters
        for(int i=0;i<k;i++)
        {
            rand = random.nextInt(rowsNum-1);
            protoClusters[i] =new KMClustering(coordinates);
            protoClusters[i].Centroid = coordinates[rand];
        }
        
        while(UNDONE)
        {
            mDistanceCache = new double[rowsNum][k];
            for(int i=0;i<k;i++)
            { 
                for(int j=0;j<rowsNum;j++)
                {
                    double dis = distance(coordinates[j], protoClusters[i].Centroid);
                    mDistanceCache[j][i]=dis;
                }
                for(int l=0;l<rowsNum;l++)
                {
                     int a = nearestCluster(mDistanceCache[l]);
                }
            }
            for(int j=0;j<rowsNum;j++)
            {     
                int a = nearestCluster(mDistanceCache[j]);
                ClusterAssign[j] = a;
                
            }
            
            //Clustering the data to 'k' Clusters
            for(int i=0;i<k;i++)
            { 
                int cc=0;
                for(int j=0;j<rowsNum;j++)
                {
                    if(ClusterAssign[j] == i)
                    {
                        cc++;
                    }
                }
                protoClusters[i].Size = cc;
                protoClusters[i].CurGroup = new int[cc];
            }
            
            //Setup the CurGroup members foreach Cluster
            for(int i=0;i<k;i++)
            { 
                int cc=0;
                for(int j=0;j<rowsNum;j++)
                {
                    if(ClusterAssign[j] == i)
                    {
                        protoClusters[i].CurGroup[cc] = j;
                        cc++;
                    }
                }
            }
            
            CalculateTheSSE();

            updateCentroid();
            times++;
        }
        
    }
    
    private void CalculateTheSSE()
    {
        SSE=0;
        sum = 0;
        for(int i=0;i<k;i++)
        {
            for(int j=0;j<protoClusters[i].CurGroup.length;j++)
            {
                //distance from each point of the cluster to it's relative centroid 
                double dis = distance(coordinates[protoClusters[i].CurGroup[j]], protoClusters[i].Centroid);
                sum+=dis*dis;//Sum the distances 
            }
            //sum+=SSE;
        }
        SSE=sum;
    }
    //update the center of clusters:
    private void updateCentroid()
    {
        newCentroids = new double[k][columnIndex];
        for(int col=0;col<columnIndex;col++){
            for(int i=0;i<k;i++)
            {
                int num = 0;
                double count=0.0;
                for(int j=0;j<rowsNum;j++)
                {
                    if(ClusterAssign[j] == i)
                    {
                        num++;
                        count += coordinates[j][col];
                    }
                }
                newCentroids[i][col] = (count/num);
            }
        }
        
        //Check if the new Centroid equal old Centroid
        for(int i=0;i<k;i++)
        {
            if(Arrays.equals(newCentroids[i], protoClusters[i].Centroid))
            {
                UNDONE = false;
            }
            else 
            {
                protoClusters[i].Centroid=newCentroids[i];
            }  
        }
    }
    
    //calculate the distance between each point and the cluster center
    //euclidean distance
    private double distance(double[] coord, double[] centroid) {
        int len = coord.length;
        double sumSquared = 0.0;
	for (int i=0; i<len; i++) {
            double v = coord[i] - centroid[i];
            sumSquared += v*v; //Sum of the DTS
        }
        return Math.sqrt(sumSquared);
    }
    
    //check the distance and return the cluster number that it belongs to for each specific point 
    private int nearestCluster(double[] cluster) {
        int nearest = -1;
	double Min = MAX_VALUE; 
        for (int c = 0; c <cluster.length; c++) {
            double d = cluster[c];
            if (d < Min) {
                Min = d;
                nearest = c;
            }
        }
        return nearest;
    }
}
