
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Peter Leonard
 */
public class ReadFile {
    public boolean unloaded = true;
    public String[] datalist=new String[10000];
    public int size=0,attributeNum=0;
    public ArrayList load=new ArrayList(10000);
    
    public ReadFile(String filename)
    {
        try{
            BufferedReader buffer = new BufferedReader( new FileReader(filename) );
            String read=new String("");
            while((read=buffer.readLine())!=null){//get the whole file information into load arraylist
                load.add(read);
                size++;
            }
            for(int i=0;i<size;i++){
                String line=""+load.get(i);
                datalist[i]=line;//use a list to carry each line of the file information
            }
            
            System.out.println("Complete File Loading!");
            System.out.println("\n=======Run Infomation=======\n");
            unloaded = false;
            String firstrow=datalist[0];
            String[] attributes=firstrow.split(";");
            attributeNum = attributes.length;
            
            System.out.println("Instances: "+(size-1));
            System.out.println("Attributes: "+attributeNum);
            for(int i=0;i<attributes.length;i++)
            {
                System.out.println("\t"+attributes[i]);
            }
            System.out.println("\n    ====K-Means====\n");
        }
        catch(IOException e){  
            System.out.println("Cannot find the file!");
        }
    }
}
